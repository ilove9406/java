package oop0318;

public class Test06_quiz {

	public static void main(String[] args) {
		
		
		//배열 연습 문제
		
		char[] ch = {'I', 'T', 'W', 'i', 'l', 'l'};
		int size =ch.length;
		
		int upperCaseCount = 0;
		int lowerCaseCount = 0;

		for (int i=0; i<size; i++) {
		    if (ch[i]>='A'&&ch[i]<='Z') {
		        upperCaseCount++;
		    } else if (ch[i]>='a'&&ch[i]<='z') {
		        lowerCaseCount++;
		    }
		}

		System.out.println("대문자 갯수: " + upperCaseCount);
		System.out.println("소문자 갯수: " + lowerCaseCount);

	
		
		
		//문2) 대/소문자 서로 바꿔서 출력하기
		//-> 출력 결과 : itwILL

		for (int i=0; i<size; i++) {
		    if (ch[i]>='A'&&ch[i]<='Z') {
		    	System.out.printf("%c",ch[i]+32);
		    } else if (ch[i]>='a'&&ch[i]<='z') {
		    	System.out.printf("%c",ch[i]-32);
		    }
		}
		// 결과 출력: itwILL

		
		//문3)모음의 갯수 구하기 aeiou AEIOU
		//모음 갯수 :2개
		int mo = 0;

		for (int i=0; i<size;i++) {
		    char c=ch[i];
		    if(c>='A'&& c<='Z') {
		    		c= (char)(c+32); //소문자로 변경
		
		}//if end
		switch (c) {
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u': mo++;
		}//switch end
	}//for end
		System.out.println("모음의 갯수: " + mo);
		
		char[][] str = {
			    {'Y', 'e', 'a', 'r'},
			    {'M', 'o', 'n', 't', 'h'},
			    {'D', 'a', 't', 'e'}
			};

			for (int r = 0; r < str.length; r++) {
			    int count = 0;
			    for (int c = 0; c < str[r].length; c++) {
			        char w = str[r][c];
			        if (w >= 'A' && w <= 'Z') {
			            w = (char) (w + 32);
			        }
			        switch (w) {
			            case 'a':
			            case 'e':
			            case 'i':
			            case 'o':
			            case 'u':
			                count++;
			                break;
			        }
			    }
			    System.out.printf("str[%d]행 모음 갯수 : %d 개\n", r, count);
			}

		
		//str[0]행 모음 :2개
		//str[1]행 모음 :1개
		//str[2]행 모음 :2개
		
		
		
		
		//문5) 대각선 방향의 각 요소의 합을 구하시오
		
		int[][] num = {
			    {4, 3, 2},
			    {5, 9, 3},
			    {6, 8, 7}
			};

			int sum = 0;	//주 대각선 합
			int sum2 = 0;	//부 대각선 합2

			// 주 대각선의 요소 합 계산
			for (int i = 0; i < num.length; i++) {
			    sum += num[i][i];
			}

			// 부 대각선의 요소 합 계산
			for (int i = 0; i < num.length; i++) {
			    sum2 += num[i][num.length - 1 - i];
			}

			System.out.println("주 대각선의 요소 합: " + sum);
			System.out.println("부 대각선의 요소 합: " + sum2);

	
		
		
		
		
		
		
		

	}	//main () end

} // class end
