/**
 * 
 */
/**
 * 
 */
module basic01_java {
	
	requires java.desktop;	//java.awt, javax.swing
	requires java.sql;	//java.sql, javax.sql
	
}