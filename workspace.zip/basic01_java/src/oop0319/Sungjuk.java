package oop0319;

public class Sungjuk {	//package 생략되어 있음
						//클래스명 첫글자는 대문자로 한다.
	
	
	
	
	//멤버변수 (필드)
	
	public String name;	// 클래스 외부에서 접근 가능하다.
	int kor, eng, mat;	// 패키지 생략되어 있ㄷ.
	private int aver;	// Sungjuk클래스 내부에서만 접근 가능하다.
	
	//멤버함수 (메소드)
	
	private void view() {}	//view end
	
	void calc() {
		//클래스 내부 멤버 간에는 Access Modifier와 상관없이 접근 가능하다.
		aver=(kor+eng+mat)/3;
		view();
		
	} //calc() end	//패키지 생략 되어 있다.
		
	
	public void disp() {
		
		System.out.println(name);
		System.out.println(kor);
		System.out.println(eng);
		System.out.println(mat);
		System.out.println(aver);
		
	} //disp() end
	
	
	
	
	
} //class end
